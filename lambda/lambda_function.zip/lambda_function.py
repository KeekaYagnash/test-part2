import json
import boto3
import mysql.connector

def lambda_handler(event, context):
     # Create an SSM client
    ssm_client = boto3.client('ssm')
    
    # Retrieve the password from Parameter Store
    parameter_name = '/vectordb_password'  # Update with the correct parameter name
    try:
        response = ssm_client.get_parameter(Name=parameter_name, WithDecryption=True)
        db_password = response['Parameter']['Value']
    except ssm_client.exceptions.ParameterNotFound:
        print(f"Parameter '{parameter_name}' not found in Parameter Store.")
        return {
            'statusCode': 500,
            'body': json.dumps('Parameter not found in Parameter Store.')
        }
    except Exception as e:
        print(f"Error retrieving parameter '{parameter_name}' from Parameter Store:", e)
        return {
            'statusCode': 500,
            'body': json.dumps('Error retrieving parameter from Parameter Store.')
        }

    # Extract file path from S3 event
    s3_event_records = event['Records']
    s3_bucket = s3_event_records[0]['s3']['bucket']['name']
    s3_object_key = s3_event_records[0]['s3']['object']['key']
    file_path = f's3://{s3_bucket}/{s3_object_key}'  # Construct S3 file path

    # extract the userID from 
    user_id = s3_object_key.split('/')[0]
    
    # Aurora MySQL database connection details
    host = 'vector-instance-ai-shop.cluster-c7emecuuajf3.af-south-1.rds.amazonaws.com'
    port = '3306'  # Default MySQL port
    user = 'vectordb'
    password = db_password
    # Update table name as required
    database = 'vectordb'
    
    # Connect to the MySQL database
    conn = mysql.connector.connect(
        host=host,
        port=port,
        user=user,
        password=password,
        database=database
    )
    
    # Create a cursor object using the cursor() method
    cursor = conn.cursor()
    
    try:
        # Create a table named "vector"
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vector (
                id INT AUTO_INCREMENT PRIMARY KEY,
                userID VARCHAR(255),
                vectorFilePath VARCHAR(255)
            )
        """)
        # print("Table 'vector' created successfully")
        
        # Insert data into the table
        vector_data = [(user_id, file_path ),]
        cursor.executemany("INSERT INTO vector (userID, vectorFilePath) VALUES (%s, %s)", vector_data)
        print("Vector data inserted successfully")
        
        # Commit changes
        conn.commit()
        
    except Exception as e:
        print("Error:", e)
        
    finally:
        # Close the cursor and connection
        cursor.close()
        conn.close()
